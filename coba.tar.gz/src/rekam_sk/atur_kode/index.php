<?php $meta_title = "Pengaturan Kode SK" ?>
<?php include "../../meta_html/common_start.php" ?>

<!-- body start -->
<a href="../">kembali</a>
<?php include_once("./code_add.php") ?>
<?php include_once("./view_code.php") ?>
<!-- body end -->

<?php include "../../meta_html/common_end.php" ?>