<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplikasi Pantau Sekolah</title>
</head>

<body>
    <ul id="menu">
        <li><a href="rekam_ks">Rekam Kegiatan Kepala Sekolah</a></li>
        <li><a href="rekam_sk">Rekam Surat Keluar</a></li>
    </ul>

</body>

</html>